<?php
/**
 * Theme Name: Mon theme
 */

// Enqueue stylesheets and scripts

function enqueue_scripts() {
    // Stylesheets
    wp_enqueue_style( 'style', get_stylesheet_uri() );
    wp_enqueue_style( 'bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css' );}
        add_action('wp_enqueue_scripts', 'wpbootstrap_enqueue_styles');

    // Scripts
    function wpbootstrap_enqueue_styles() {
    wp_enqueue_script( 'script', get_template_directory_uri() . '/js/main.js', array(), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'enqueue_scripts' );

// Register navigation menu
function register_menus() {
    register_nav_menu( 'primary', 'Menu principal' );
}
add_action( 'init', 'register_menus' );

// Add theme support
function theme_support() {
    // Add title tag support
    add_theme_support( 'title-tag' );

    // Add post thumbnails support
    add_theme_support( 'post-thumbnails' );

    // Add custom logo support
    add_theme_support( 'custom-logo', array(
        'height'      => 100,
        'width'       => 100,
        'flex-width'  => true,
        'flex-height' => true,
    ) );

    // Add editor styles
    add_theme_support( 'editor-styles' );
    add_editor_style( 'editor-style.css' );
}
add_action( 'after_setup_theme', 'theme_support' );

// Add custom image sizes
function mon_theme_custom_image_sizes() {
    add_image_size( 'mon-voyage-slider', 800, 400, true );
    add_image_size( 'mon-voyage-thumbnail', 300, 200, true );
}
add_action( 'after_setup_theme', 'mon_theme_custom_image_sizes' );

// Customize excerpt length and more
function mon_theme_custom_excerpt( $length ) {
    return 30; // Set your desired excerpt length in words
}
add_filter( 'excerpt_length', 'mon_theme_custom_excerpt' );

function mon_theme_excerpt_more( $more ) {
    return '...'; // Customize the excerpt more text
}
add_filter( 'excerpt_more', 'mon_theme_excerpt_more' );



function montheme_document_title_parts($title){
    return $title;
}

add_action('document_title_parts','montheme_document_title_parts');