<?php get_header(); ?>

  <header class="jumbotron">
    <div class="container text-center">
      <h1 class="display-4">Bienvenue sur Mon Site</h1>
      <p class="lead">Un site pour vous informer et vous connecter avec nous.</p>
      <a class="btn btn-primary btn-lg" href="#" role="button">En savoir plus</a>
    </div>
  </header>

  <section class="container">
    <div class="row">
      <div class="col-md-6">
        <h2>A propos de nous</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam aliquet, tortor a condimentum consequat, diam ex scelerisque purus, ut commodo leo purus id urna.</p>
      </div>
      <div class="col-md-6">
        <h2>Nos services</h2>
        <ul>
          <li>Service 1</li>
          <li>Service 2</li>
          <li>Service 3</li>
        </ul>
      </div>
    </div>
  </section>


<?php get_footer(); ?>