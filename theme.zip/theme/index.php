<?php get_header(); ?>


<!-- <h1 class="entry-title"><?php the_title(); ?></h1> -->

<h2>Le menu </h2>
<main id="primary" class="site-main">
    <div class="container">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
            <div class="card" style="width: 18rem;">
                    <div class="card-body">
                        <img src="https://media.tarkett-image.com/large/TH_25094225_25187225_001.jpg" class="card-img-top" alt="bababbbababba">
                        <h5 class="card-title"><?php the_title() ?></h5>
                        <p class="card-text"><?php the_content() ?></p>
                        <a href="<?php the_permalink() ?>" class="btn btn-primary">Voir l'article</a>
                    </div>
                    </div>
                <?php endwhile; ?>
        <?php else : ?>
            <p>PAS D'ARTICLE</p>
        <?php endif; ?>
</main>

<?php get_footer(); ?>

