    </div> <!-- #content -->

    <footer id="colophon" class="site-footer">
        <div class="container">
            <div class="site-info">
                <?php if ( has_nav_menu( 'footer' ) ) : ?>
                    <nav class="footer-navigation">
                        <?php
                            wp_nav_menu( array(
                                'theme_location' => 'footer',
                                'menu_id'        => 'footer-menu',
                            ) );
                        ?>
                    </nav>
                <?php endif; ?>

                <p class="site-credits">
                    <?php esc_html_e( '©', 'mon-theme' ); ?>
                    <?php echo date( 'Y' ); ?>
                    <?php esc_html_e( 'Grégoire Geffray.', 'mon-theme' ); ?>
                </p>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>

