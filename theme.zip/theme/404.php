<?php get_header(); ?>

  <div class="error-container">
    <div>
      <h1 class="display-1">404</h1>
      <h2>Oops! Cette page est introuvable.</h2>
      <p>La page que vous recherchez n'existe pas. Veuillez vérifier l'URL ou revenir à la <a href="/">page d'accueil</a>.</p>
    </div>
  </div>

<?php wp_footer(); ?>